// import express, { Request, Response } from 'express';
// import bodyParser from 'body-parser';
// import cors from 'cors';
// import fs from 'fs';
// import path from 'path';

// const app = express();
// const PORT = 3000;
// const DB_FILE = 'db.json';

// app.use(cors());
// app.use(bodyParser.json());

// const dbFilePath = path.join(__dirname, DB_FILE);

// // Ensure db.json exists and initialize if not
// if (!fs.existsSync(dbFilePath)) {
//     fs.writeFileSync(dbFilePath, '[]');
// }

// app.get('/ping', (req: Request, res: Response) => {
//     res.json({ success: true });
// });

// app.post('/submit', (req: Request, res: Response) => {
//     console.log(req.body);
//     const { Name, Email, Phone, GitHub, Time } = req.body;
//     console.log('Received submission data:', {Name, Email, Phone, GitHub, Time});

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent); // Attempting to parse JSON here
//         }

//         const Timestamp = new Date().toISOString();
//         // Get current timestamp in ISO format

//         const newSubmission = {
//             id: submissions.length + 1, // Generate unique id based on the length of existing submissions
//             Name,
//             Email,
//             Phone,
//             GitHub,
//             Time,
//             Timestamp // Include the timestamp in the submission object
//         };

//         submissions.push(newSubmission);
//         console.log(submissions)

//         fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));

//         res.status(201).json({ success: true, message: 'Submission saved successfully!' });
//     } catch (err) {
//         console.error('Error saving submission:', err);
//         res.status(500).json({ error: 'Failed to save submission' });
//     }
// });

// app.get('/read', (req: Request, res: Response) => {
//     try {
//         const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//         const submissions = JSON.parse(fileContent); // Attempting to parse JSON here
//         res.status(200).json(submissions);
//     } catch (err) {
//         console.error('Error reading submissions:', err);
//         res.status(500).json({ error: 'Failed to read submissions' });
//     }
// });

// app.listen(PORT, () => {
//     console.log(`Server is running on http://localhost:${PORT}`);
// });



// import express, { Request, Response } from 'express';
// import bodyParser from 'body-parser';
// import cors from 'cors';
// import fs from 'fs';
// import path from 'path';

// const app = express();
// const PORT = 3000;
// const DB_FILE = 'db.json';

// app.use(cors());
// app.use(bodyParser.json());

// const dbFilePath = path.join(__dirname, DB_FILE);

// // Ensure db.json exists and initialize if not
// if (!fs.existsSync(dbFilePath)) {
//     fs.writeFileSync(dbFilePath, '[]');
// }

// app.get('/ping', (req: Request, res: Response) => {
//     res.json({ success: true });
// });

// app.post('/submit', (req: Request, res: Response) => {
//     console.log(req.body);
//     const { Name, Email, Phone, GitHub, Time } = req.body;
//     console.log('Received submission data:', { Name, Email, Phone, GitHub, Time });

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent);
//         }

//         const Timestamp = new Date().toISOString();

//         const newSubmission = {
//             id: submissions.length + 1, // Generate unique id based on the length of existing submissions
//             Name,
//             Email,
//             Phone,
//             GitHub,
//             Time,
//             Timestamp
//         };

//         submissions.push(newSubmission);
//         console.log(submissions)

//         fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));

//         res.status(201).json({ success: true, message: 'Submission saved successfully!' });
//     } catch (err) {
//         console.error('Error saving submission:', err);
//         res.status(500).json({ error: 'Failed to save submission' });
//     }
// });

// app.get('/read', (req: Request, res: Response) => {
//     try {
//         const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//         const submissions = JSON.parse(fileContent);
//         res.status(200).json(submissions);
//     } catch (err) {
//         console.error('Error reading submissions:', err);
//         res.status(500).json({ error: 'Failed to read submissions' });
//     }
// });

// app.put('/edit/:id', (req: Request, res: Response) => {
//     const { id } = req.params;
//     const { Name, Email, Phone, GitHub, Time } = req.body;

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent);
//         }

//         const index = submissions.findIndex(submission => submission.id === parseInt(id));

//         if (index !== -1) {
//             submissions[index] = { ...submissions[index], Name, Email, Phone, GitHub, Time };
//             fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));
//             res.status(200).json({ success: true, message: 'Submission updated successfully!' });
//         } else {
//             res.status(404).json({ error: 'Submission not found' });
//         }
//     } catch (err) {
//         console.error('Error updating submission:', err);
//         res.status(500).json({ error: 'Failed to update submission' });
//     }
// });

// app.delete('/delete/:id', (req: Request, res: Response) => {
//     const { id } = req.params;

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent);
//         }

//         const index = submissions.findIndex(submission => submission.id === parseInt(id));

//         if (index !== -1) {
//             submissions.splice(index, 1);
//             fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));
//             res.status(200).json({ success: true, message: 'Submission deleted successfully!' });
//         } else {
//             res.status(404).json({ error: 'Submission not found' });
//         }
//     } catch (err) {
//         console.error('Error deleting submission:', err);
//         res.status(500).json({ error: 'Failed to delete submission' });
//     }
// });

// app.listen(PORT, () => {
//     console.log(`Server is running on http://localhost:${PORT}`);
// });


// import express, { Request, Response } from 'express';
// import bodyParser from 'body-parser';
// import cors from 'cors';
// import fs from 'fs';
// import path from 'path';

// const app = express();
// const PORT = 3000;
// const DB_FILE = 'db.json';

// app.use(cors());
// app.use(bodyParser.json());

// const dbFilePath = path.join(__dirname, DB_FILE);

// // Ensure db.json exists and initialize if not
// if (!fs.existsSync(dbFilePath)) {
//     fs.writeFileSync(dbFilePath, '[]');
// }

// // Function to generate a new ID for submissions
// function generateId() {
//     let submissions: any[] = [];

//     if (fs.existsSync(dbFilePath)) {
//         const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//         submissions = JSON.parse(fileContent);
//     }

//     // Generate new ID based on existing submissions
//     return submissions.length > 0 ? submissions[submissions.length - 1].id + 1 : 1;
// }

// app.get('/ping', (req: Request, res: Response) => {
//     res.json({ success: true });
// });

// app.post('/submit', (req: Request, res: Response) => {
//     console.log(req.body);
//     const { Name, Email, Phone, GitHub, Time } = req.body;
//     console.log('Received submission data:', { Name, Email, Phone, GitHub, Time });

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent);
//         }

//         const Timestamp = new Date().toISOString();

//         // Generate new ID
//         const newSubmission = {
//             id: generateId(), // Generate unique id based on the length of existing submissions
//             Name,
//             Email,
//             Phone,
//             GitHub,
//             Time,
//             Timestamp
//         };

//         submissions.push(newSubmission);
//         console.log(submissions)

//         fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));

//         res.status(201).json({ success: true, message: 'Submission saved successfully!', id: newSubmission.id });
//     } catch (err) {
//         console.error('Error saving submission:', err);
//         res.status(500).json({ error: 'Failed to save submission' });
//     }
// });

// app.get('/read', (req: Request, res: Response) => {
//     try {
//         const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//         const submissions = JSON.parse(fileContent);
//         res.status(200).json(submissions);
//     } catch (err) {
//         console.error('Error reading submissions:', err);
//         res.status(500).json({ error: 'Failed to read submissions' });
//     }
// });

// app.put('/edit/:id', (req: Request, res: Response) => {
//     const { id } = req.params;
//     const { Name, Email, Phone, GitHub, Time } = req.body;

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent);
//         }

//         const index = submissions.findIndex(submission => submission.id === parseInt(id));

//         if (index !== -1) {
//             submissions[index] = { ...submissions[index], Name, Email, Phone, GitHub, Time };
//             fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));
//             res.status(200).json({ success: true, message: 'Submission updated successfully!' });
//         } else {
//             res.status(404).json({ error: 'Submission not found' });
//         }
//     } catch (err) {
//         console.error('Error updating submission:', err);
//         res.status(500).json({ error: 'Failed to update submission' });
//     }
// });

// app.delete('/delete/:id', (req: Request, res: Response) => {
//     const { id } = req.params;

//     try {
//         let submissions: any[] = [];

//         if (fs.existsSync(dbFilePath)) {
//             const fileContent = fs.readFileSync(dbFilePath, 'utf8');
//             submissions = JSON.parse(fileContent);
//         }

//         const index = submissions.findIndex(submission => submission.id === parseInt(id));

//         if (index !== -1) {
//             submissions.splice(index, 1);
//             // Update the IDs of the remaining submissions
//             submissions.forEach((submission, i) => {
//                 submission.id = i + 1;
//             });
//             fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));
//             res.status(200).json({ success: true, message: 'Submission deleted successfully!' });
//         } else {
//             res.status(404).json({ error: 'Submission not found' });
//         }
//     } catch (err) {
//         console.error('Error deleting submission:', err);
//         res.status(500).json({ error: 'Failed to delete submission' });
//     }
// });

// app.listen(PORT, () => {
//     console.log(`Server is running on http://localhost:${PORT}`);
// });


import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = 3000;
const DB_FILE = 'db.json';

app.use(cors());
app.use(bodyParser.json());

const dbFilePath = path.join(__dirname, DB_FILE);

// Ensure db.json exists and initialize if not
if (!fs.existsSync(dbFilePath)) {
    fs.writeFileSync(dbFilePath, '[]');
}

// Middleware to parse JSON
app.use(express.json());

// GET route to check if server is running
app.get('/ping', (req: Request, res: Response) => {
    res.json({ success: true });
});

// POST route to submit data
app.post('/submit', (req: Request, res: Response) => {
    const { Name, Email, Phone, GitHub, Time } = req.body;
    console.log('Received submission data:', { Name, Email, Phone, GitHub, Time });

    try {
        let submissions: any[] = [];

        if (fs.existsSync(dbFilePath)) {
            const fileContent = fs.readFileSync(dbFilePath, 'utf8');
            submissions = JSON.parse(fileContent); // Attempting to parse JSON here
        }

        const Timestamp = new Date().toISOString();
        const newSubmission = {
            id: submissions.length + 1,
            Name,
            Email,
            Phone,
            GitHub,
            Time,
            Timestamp
        };

        submissions.push(newSubmission);
        fs.writeFileSync(dbFilePath, JSON.stringify(submissions, null, 2));

        res.status(201).json({ success: true, message: 'Submission saved successfully!' });
    } catch (err) {
        console.error('Error saving submission:', err);
        res.status(500).json({ error: 'Failed to save submission' });
    }
});

// GET route to fetch all submissions or by email
app.get('/read', (req: Request, res: Response) => {
    try {
        const fileContent = fs.readFileSync(dbFilePath, 'utf8');
        const submissions = JSON.parse(fileContent);

        // Check if email query parameter is provided
        const { email } = req.query;
        if (email) {
            const filteredSubmissions = submissions.filter((submission: any) => submission.Email === email);
            res.status(200).json(filteredSubmissions);
        } else {
            res.status(200).json(submissions);
        }
    } catch (err) {
        console.error('Error reading submissions:', err);
        res.status(500).json({ error: 'Failed to read submissions' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
